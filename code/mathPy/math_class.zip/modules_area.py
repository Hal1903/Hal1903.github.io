def area_circle(radius):
    return 3.14159 * radius ** 2

def area_rectangle(width, height):
    return width * height

print("Using modules_area.py.")

if __name__ == "__main__":
    print("You are runnng modules_area.py!")